package qualification.round2017;

/**
 * Created by kyle.mcallister on 2/23/2017.
 */
public class Solution {
}
